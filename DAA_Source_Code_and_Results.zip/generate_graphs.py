"""Create labelled benchmark graphs from results.csv. Run after daa_benchmark.py."""
import csv
from pathlib import Path
import matplotlib.pyplot as plt

HERE = Path(__file__).resolve().parent
with (HERE / "results.csv").open(newline="", encoding="utf-8") as f:
    rows = list(csv.DictReader(f))
sizes = sorted({int(r["dataset_size"]) for r in rows})
algorithms = ["Linear Search", "Recursive Binary Search", "Jump Search"]

def mean(rows, alg, n, field):
    vals = [float(r[field]) for r in rows if r["algorithm"] == alg and int(r["dataset_size"]) == n]
    return sum(vals) / len(vals) if vals else 0

for field, ylabel, title, filename, logy in [
    ("search_time_seconds", "Average search time (seconds)", "Dataset Size vs. Average Search Time", "graph_average_search_time.png", True),
    ("key_comparisons", "Average key comparisons", "Dataset Size vs. Average Key Comparisons", "graph_average_comparisons.png", False),
]:
    plt.figure(figsize=(10, 6))
    for alg in algorithms:
        ys = [mean(rows, alg, n, field) for n in sizes]
        plt.plot(sizes, ys, marker="o", label=alg)
    plt.xscale("log")
    if logy: plt.yscale("log")
    plt.xlabel("Dataset size (records)")
    plt.ylabel(ylabel)
    plt.title(title)
    plt.grid(True, which="both", linestyle="--", alpha=0.5)
    plt.legend()
    plt.tight_layout()
    plt.savefig(HERE / filename, dpi=200)
    plt.close()
print("Graphs saved to the script folder.")
