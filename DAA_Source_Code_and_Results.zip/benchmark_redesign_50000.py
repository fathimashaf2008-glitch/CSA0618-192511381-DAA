"""
Task 12 redesign benchmark: dictionary/hash-table exact-key lookup.
Run separately: python benchmark_redesign_50000.py
Measures index-build time and 50,000 lookups against 1,000,000 records.
Results are written to redesign_50000_results.csv from the actual run.
"""
import csv, random, time
from pathlib import Path

NAME = "Fathima Shafreena F"
REGISTRATION = "192511381"
SEED = int(REGISTRATION[-4:])
N = 1_000_000
LOOKUPS = 50_000
HERE = Path(__file__).resolve().parent

def main():
    rng = random.Random(SEED + N)
    records = set()
    while len(records) < N - 1:
        records.add(rng.randrange(10_000_000, 99_999_999))
    records.add(int(REGISTRATION))
    records.discard(int(REGISTRATION) + 1)
    values = list(records)
    while len(values) < N:
        v = rng.randrange(10_000_000, 99_999_999)
        if v not in records and v != int(REGISTRATION) + 1:
            records.add(v); values.append(v)
    # Build the dictionary index once; values are record IDs.
    start = time.perf_counter()
    index = {key: key for key in values}
    build_time = time.perf_counter() - start
    # Alternate known successful and known unsuccessful keys.
    keys = [int(REGISTRATION) if i % 2 == 0 else int(REGISTRATION) + 1 for i in range(LOOKUPS)]
    start = time.perf_counter()
    found_count = sum(1 for key in keys if key in index)
    lookup_total = time.perf_counter() - start
    assert found_count == LOOKUPS // 2, f"Expected {LOOKUPS // 2} hits; got {found_count}"
    output = HERE / "redesign_50000_results.csv"
    with output.open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["student_name","registration_number","dataset_size","lookup_count","successful_lookups","unsuccessful_lookups","index_build_seconds","total_lookup_seconds","average_lookup_microseconds","correctness"])
        w.writerow([NAME, REGISTRATION, N, LOOKUPS, found_count, LOOKUPS-found_count, f"{build_time:.10g}", f"{lookup_total:.10g}", f"{lookup_total/LOOKUPS*1e6:.10g}", "PASS"])
    print(f"Student: {NAME} | Registration number: {REGISTRATION}")
    print(f"Records indexed: {N:,}")
    print(f"Lookups performed: {LOOKUPS:,}")
    print(f"Successful / unsuccessful: {found_count:,} / {LOOKUPS-found_count:,}")
    print(f"Index build time (s): {build_time:.6f}")
    print(f"Total lookup time (s): {lookup_total:.6f}")
    print(f"Average lookup time (microseconds): {lookup_total/LOOKUPS*1e6:.6f}")
    print("Correctness: PASS")
    print(f"Results saved to: {output}")
    print("Run this on the target computer before quoting these timings in the report.")

if __name__ == "__main__":
    main()
