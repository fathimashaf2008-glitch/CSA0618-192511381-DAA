"""
DAA Assignment 1 benchmark: Linear Search, Recursive Binary Search, Jump Search.
Run: python daa_benchmark.py
The script generates results.csv from actual measurements on the machine running it.
Student details below are based on the supplied screenshots; edit NAME/REGISTRATION if needed.
"""
import csv
import random
import time
import math
from pathlib import Path

NAME = "Fathima Shafreena F"
REGISTRATION = "192511381"
SEED = int(REGISTRATION[-4:])
SIZES = [1_000, 10_000, 100_000, 1_000_000]
REPEATS = 3
OUT = Path(__file__).resolve().parent
CSV_PATH = OUT / "results.csv"

def linear_search(a, key):
    comparisons = 0
    for i, value in enumerate(a):
        comparisons += 1
        if value == key:
            return i, comparisons
    return -1, comparisons

def recursive_binary_search(a, key, low=0, high=None, comparisons=None):
    # Comparisons is a mutable one-item list to count comparisons across recursion.
    if high is None:
        high = len(a) - 1
    if comparisons is None:
        comparisons = [0]
    if low > high:
        return -1, comparisons[0]
    mid = (low + high) // 2
    comparisons[0] += 1
    if a[mid] == key:
        return mid, comparisons[0]
    comparisons[0] += 1
    if key < a[mid]:
        return recursive_binary_search(a, key, low, mid - 1, comparisons)
    return recursive_binary_search(a, key, mid + 1, high, comparisons)

def jump_search(a, key):
    n = len(a)
    if n == 0:
        return -1, 0
    step = max(1, int(math.sqrt(n)))
    prev = 0
    comparisons = 0
    while prev < n:
        end = min(prev + step, n)
        comparisons += 1
        if a[end - 1] >= key:
            for i in range(prev, end):
                comparisons += 1
                if a[i] == key:
                    return i, comparisons
            return -1, comparisons
        prev = end
    return -1, comparisons

def timed_search(fn, data, key):
    samples, result, comparisons = [], None, None
    for _ in range(REPEATS):
        start = time.perf_counter()
        result, comparisons = fn(data, key)
        samples.append(time.perf_counter() - start)
    return result, comparisons, sum(samples) / len(samples)

def main():
    print(f"Student: {NAME}")
    print(f"Registration number: {REGISTRATION}")
    print(f"Dataset seed: {SEED}")
    print(f"Successful key: {REGISTRATION}")
    print(f"Unsuccessful key: {int(REGISTRATION) + 1}")
    rows = []
    for n in SIZES:
        print(f"\nPreparing {n:,} records...")
        rng = random.Random(SEED + n)
        # Keep registration numbers unique and include the requested successful key.
        data = set()
        while len(data) < n - 1:
            data.add(rng.randrange(10_000_000, 99_999_999))
        data.add(int(REGISTRATION))
        unsorted = list(data)
        # Ensure the unsuccessful key is not accidentally present.
        unsorted = [x for x in unsorted if x != int(REGISTRATION) + 1]
        while len(unsorted) < n:
            candidate = rng.randrange(10_000_000, 99_999_999)
            if candidate not in data and candidate != int(REGISTRATION) + 1:
                data.add(candidate); unsorted.append(candidate)
        # Keep all keys unique; sorting is a separate, explicitly measured preprocessing step.
        start = time.perf_counter()
        sorted_data = sorted(unsorted)
        sort_seconds = time.perf_counter() - start
        for key, condition in [(int(REGISTRATION), "successful"), (int(REGISTRATION) + 1, "unsuccessful")]:
            for name, fn, arr in [
                ("Linear Search", linear_search, unsorted),
                ("Recursive Binary Search", recursive_binary_search, sorted_data),
                ("Jump Search", jump_search, sorted_data),
            ]:
                idx, comps, elapsed = timed_search(fn, arr, key)
                expected = key in arr
                assert (idx != -1) == expected, f"Correctness failure: {name}, n={n}, key={key}"
                rows.append({
                    "student_name": NAME, "registration_number": REGISTRATION,
                    "dataset_seed": SEED + n, "dataset_size": n, "search_key": key,
                    "test_condition": condition, "found": idx != -1, "algorithm": name,
                    "key_comparisons": comps, "search_time_seconds": f"{elapsed:.10g}",
                    "preprocessing_sort_time_seconds": f"{sort_seconds:.10g}" if name != "Linear Search" else "0",
                    "repeats": REPEATS
                })
        print(f"Completed dataset size: {n:,}")
    with CSV_PATH.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader(); writer.writerows(rows)
    print("\nAll correctness tests passed.")
    print(f"Benchmark results saved to {CSV_PATH}")
    print(f"Student: {NAME} | Registration number: {REGISTRATION}")
    print("Note: measurements are machine- and run-dependent.")

if __name__ == "__main__":
    main()
