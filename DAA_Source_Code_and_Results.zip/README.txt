DAA ASSIGNMENT 1 DELIVERABLES

Files:
- DAA_Assignment1_Report.docx: editable report.
- DAA_Assignment1_Report.pdf: PDF report.
- daa_benchmark.py: runs correctness tests and measures the three algorithms.
- generate_graphs.py: creates labelled graphs from results.csv.
- results.csv: placeholder until the benchmark is run on your computer.
- Submission checklist is included in the report.

IMPORTANT:
The supplied screenshots show preliminary results, but the values and graph labels are not fully consistent (for example, a graph calls search time 'sorting time', and sorting time is recorded as zero for Linear Search). The report therefore does not treat those figures as validated evidence. Run the benchmark script to create a new reproducible CSV from actual measurements, then run generate_graphs.py.

Run:
1. Install Python 3.10+.
2. Open Command Prompt in this folder.
3. Run: python daa_benchmark.py
4. Run: python generate_graphs.py
5. Inspect results.csv and the generated PNG files before submission.
6. Replace the terminal screenshot placeholder in the report with your own full terminal screenshot.
7. Confirm the third algorithm is permitted for your roll-number group from the official submission rules.

Task 12 redesigned workload:
- Run: python benchmark_redesign_50000.py
- This builds a hash-table index for 1,000,000 records and measures 50,000 lookups.
- It writes redesign_50000_results.csv with actual measured values.
